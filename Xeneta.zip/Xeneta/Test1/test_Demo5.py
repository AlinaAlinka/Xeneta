# Checking that we are on the correct page and "Live Group Demo of the Xeneta Platform" page is reachable

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")


driver.get("https://www.xeneta.com/demo")

time.sleep(8) # Wait for 8 seconds until the page loads

# Click the "See how here" button
driver.find_element_by_xpath("//*[@id='cta_button_1816946_e2201b1b-2e3a-40e7-b483-f161f0e38433']").click()

print(driver.title)  # Title of the page
print("'Live Group Demo of the Xeneta Platform' page is reached")

driver.quit()  # Close all windows