# Checking that we are on the correct page and "Hamburg" page is reachable

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")

driver.get("https://www.xeneta.com/careers")

time.sleep(8) # Wait for 8 seconds until the page loads

# Click on the "Visit" button for Hamburg page
driver.find_element_by_xpath("//*[@id='slick-slide22']/div/div/div/a[2]").click()

time.sleep(8) # Wait for 8 seconds until the page loads

driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_widget_27868997044']/div/div/div/div/ul/li[2]/img")


print(driver.title)  # Title of the page
print("'Hamburg' page is reached")

driver.close()  # Close the browser
