# Checking that we are on the correct page and "Watch Xeneta in Action" page is reachable

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")


driver.get("https://www.xeneta.com/demo")

time.sleep(8) # Wait for 8 seconds until the page loads

# Click the "Watch now" button
driver.find_element_by_xpath("//*[@id='cta_button_1816946_336f42c6-1948-463d-a09c-bb86170f7da3']").click()

time.sleep(8) # Wait for 8 seconds until the page loads

driver.find_element_by_xpath("//*[@id='hsForm_8c92c318-ab09-46db-a240-a2827276050d']/div[10]/div[2]/input")


print(driver.title)  # Title of the page
print("'Watch Xeneta in Action' page is reached")

driver.close()  # Close the window