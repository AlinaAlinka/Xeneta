#Checking that we are on the correct page and the top and bottom bar elements are present on the page

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")

driver.get("https://www.xeneta.com/careers")

links=driver.find_elements(By.TAG_NAME, "a") # Find all links on the page

# Checking that top bsrs' elements are present
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[1]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[2]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[3]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[4]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[5]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582288261238129_']/ul/li[6]/a")

# Checking that bottom bars' elements are present
driver.find_element_by_xpath("//*[@id='hs-link-module_158638082393118_']")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_module_158713171994500']/ul/li[1]/a/i")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_module_158713171994500']/ul/li[2]/a/i")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_module_158713171994500']/ul/li[3]/a/i")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_module_158713171994500']/ul/li[4]/a/i")

driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464493681345_']/ul/li[1]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464493681345_']/ul/li[2]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464493681345_']/ul/li[3]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464567336351_']/ul/li[1]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464567336351_']/ul/li[2]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464567336351_']/ul/li[3]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464573163353_']/ul/li[1]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464573163353_']/ul/li[2]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464573163353_']/ul/li[3]/a")
driver.find_element_by_xpath("//*[@id='hs_menu_wrapper_module_1582464573163353_']/ul/li[4]/a")

print(driver.title)  # Title of the page
# How many links are on the page
print("The top and bottom bar elements are present on the page. Number of links om the page is:", len(links))

driver.close()  # Close the window