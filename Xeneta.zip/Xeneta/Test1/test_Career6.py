# Checking that we are on the correct page and all tabs from "Values" part are reachable.

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")

driver.get("https://www.xeneta.com/careers")

time.sleep(8) # Wait for 8 seconds until the page loads

driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_widget_27351556886']/div/div/div/ul/li[1]").click()
driver.find_element_by_xpath("//*[@id='Xenetaisone-1']/div/div/div[1]/div/img")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_widget_27351556886']/div/div/div/ul/li[2]").click()
driver.find_element_by_xpath("//*[@id='Modernizationthroughdata-2']/div/div/div[1]/div/img")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_widget_27351556886']/div/div/div/ul/li[3]").click()
driver.find_element_by_xpath("//*[@id='VarietyandFairness-3']/div/div/div[1]/div/img")
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_widget_27351556886']/div/div/div/ul/li[4]").click()
driver.find_element_by_xpath("//*[@id='TransparencybuildsTrust-4']/div/div/div[1]/div/img")


print(driver.title)  # Title of the page
print("All tabs from 'Values' part are reachable")

driver.close()  # Close the browser
