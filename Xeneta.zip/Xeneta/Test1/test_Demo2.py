# Checking that we are on the correct page and "Get a Personalized Demo" page is reachable

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")


driver.get("https://www.xeneta.com/demo")

time.sleep(8) # Wait for 8 seconds until the page loads

# Click the "Schedule online demo" button
driver.find_element_by_xpath("//*[@id='cta_button_1816946_25c09f7c-8754-431d-bcc6-d57e364e9f03']").click()

time.sleep(8) # Wait for 8 seconds until the page loads

driver.find_element_by_xpath("//*[@id='hsForm_0e41acd7-514b-4f39-9a5e-59831bb5592d']/div[14]/div[2]/input")


print(driver.title)  # Title of the page
print("'Get a Personalized Demo' page is reached")

driver.quit()  # Close all windows