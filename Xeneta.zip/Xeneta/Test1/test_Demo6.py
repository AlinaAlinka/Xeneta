# Checking that we are on the correct page and can start the video

from selenium import webdriver
import time

# Here is the path where the chrome driver is located on my computer. Please, edit it with your own path
driver = webdriver.Chrome(executable_path=r"C:\Users\Lenovo\Drivers\chromedriver_win32\chromedriver.exe")


driver.get("https://www.xeneta.com/demo")

time.sleep(8) # Wait for 8 seconds until the page loads

# Click the "Watch now" button
driver.find_element_by_xpath("//*[@id='hs_cos_wrapper_module_1599386326062276']/div/div/div/div/div[2]/div/a/i").click()

time.sleep(9) # To be sure that video was started



print(driver.title)  # Title of the page
print("Video was started")

driver.close()  # Close the window